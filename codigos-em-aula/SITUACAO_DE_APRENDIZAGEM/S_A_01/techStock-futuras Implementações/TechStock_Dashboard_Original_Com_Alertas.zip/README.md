# TechStock — seu Dashboard original com alertas React

Atualizei o **Dashboard/index.jsx** que você enviou. O formulário, os cards, o catálogo, as opções de rádio, a paginação e a URL da API foram preservados.

## Onde colocar os arquivos

- `src/pages/Dashboard/index.jsx`: substitua apenas este arquivo pelo novo.
- `src/components/Alertas/index.jsx` e `styled.jsx`: use estes dois arquivos caso ainda não tenha colocado os alertas animados no projeto. São da versão de 2 segundos.
- **Não altere** seu `src/pages/Dashboard/styled.jsx`. Ele continua exatamente como estava.

## Funcionamento

- Cadastro: depois do `POST` bem-sucedido, mostra "Equipamento cadastrado com sucesso!".
- Edição: depois do `PUT` bem-sucedido, mostra "Equipamento editado com sucesso!".
- Exclusão: o botão Excluir abre a confirmação. Só após clicar em "Sim, excluir" é feito o `DELETE`. Em seguida mostra sucesso.
- Sucesso: surge suavemente, espera 2 segundos e desaparece com animação de 0,4 segundo, sem botão.
- Cancelar exclusão: fecha o aviso e não faz nenhuma requisição.

## SweetAlert2

A importação e todas as chamadas `Swal.fire()` foram removidas. Se nenhuma outra tela utiliza SweetAlert2, pode executar `npm uninstall sweetalert2` no frontend.

## Observação

Os alertas não substituem as respostas do backend. Caso a requisição falhe, não será mostrado um sucesso indevido. Como na versão original, os erros de rede ainda podem aparecer no console; não foi acrescentada uma terceira tela de erro.

## Teste básico

1. Rode backend e frontend.
2. Cadastre: verifique o sucesso automático.
3. Edite: verifique o sucesso automático.
4. Clique em excluir e em Cancelar: o registro deve permanecer.
5. Clique em excluir e confirme: o registro será apagado e o sucesso aparecerá.
