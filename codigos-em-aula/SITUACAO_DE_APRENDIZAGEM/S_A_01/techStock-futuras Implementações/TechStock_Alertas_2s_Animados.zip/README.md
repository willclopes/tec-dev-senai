# TechStock — Alertas automáticos com animação

React + Styled Components. Sem SweetAlert2.

## Como funciona

- **ConfirmarExclusao**: continua com os botões **Cancelar** e **Sim, excluir**. A entrada é suave.
- **AlertaSucesso**: aparece suavemente, aguarda 2 segundos, inicia a saída de 400 milissegundos e desaparece sozinho.
- O mesmo **AlertaSucesso** serve para cadastro, edição e exclusão, mudando somente a mensagem.
- As cores vêm da sua paleta do TechStock. Não é necessário criar cores novas.

## Arquivos para substituir

Copie estes dois arquivos para seu projeto:

```
frontend/src/components/Alertas/index.jsx
frontend/src/components/Alertas/styled.jsx
```

## O Dashboard precisa mudar?

**Não.** Se você já usa os alertas como no guia anterior, o Dashboard continua igual:

```jsx
{mensagemSucesso !== '' && (
    <AlertaSucesso
        mensagem={mensagemSucesso}
        aoFechar={() => setMensagemSucesso('')}
    />
)}
```

Após cada operação bem-sucedida:

```jsx
setMensagemSucesso('Equipamento cadastrado com sucesso!')
setMensagemSucesso('Equipamento editado com sucesso!')
setMensagemSucesso('Equipamento excluído com sucesso!')
```

Não coloque o fechamento manual em botões. `AlertaSucesso` chama `aoFechar` sozinho.

## Mudar o tempo

No arquivo `index.jsx`, localize:

```js
}, 2000) // 2 segundos antes de começar a sair
...
}, 2400) // 2 segundos + 400 ms para a animação de saída
```

Por exemplo, se quiser 3 segundos, altere para `3000` e `3400`.

## Prévia

Abra `preview-alertas.html` no navegador. Os exemplos de sucesso desaparecem automaticamente.

**Observação:** não modifiquei os arquivos do seu Dashboard, pois não tenho o código atual. Os componentes mantêm as mesmas propriedades (`mensagem`, `aoFechar`, `aoCancelar`, `aoConfirmar`).
