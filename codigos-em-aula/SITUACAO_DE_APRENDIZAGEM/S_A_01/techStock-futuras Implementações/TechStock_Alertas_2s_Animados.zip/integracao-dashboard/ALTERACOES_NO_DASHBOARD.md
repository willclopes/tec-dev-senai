# Dashboard — SOMENTE as alterações necessárias

Não substitua o `pages/Dashboard/index.jsx` inteiro. Copie só os trechos abaixo para o arquivo que você já usa.

## 1. Imports

Adicione na parte de cima do Dashboard:

```jsx
import { useState } from 'react'
import { ConfirmarExclusao, AlertaSucesso } from '../../components/Alertas'
```

**Atenção:** se seu arquivo já importa `useState`, aproveite a mesma importação, sem duplicar.

## 2. Estados

Dentro da função `Dashboard`, adicione:

```jsx
// ID do equipamento que queremos excluir.
const [idParaExcluir, setIdParaExcluir] = useState(null)

// Texto que será mostrado no alerta de sucesso.
const [mensagemSucesso, setMensagemSucesso] = useState('')
```

## 3. Botão Excluir

**No botão Excluir existente**, em vez de apagar diretamente, apenas abra a confirmação:

```jsx
onClick={() => setIdParaExcluir(equipamento.id)}
```

Se o botão Excluir estiver dentro do componente `Catalogo`, passe uma função como propriedade do Dashboard:

```jsx
<Catalogo
    // mantenha aqui todas as propriedades que você já usa
    aoPedirExclusao={setIdParaExcluir}
/>
```

E no botão Excluir do `Catalogo`, utilize:

```jsx
onClick={() => aoPedirExclusao(equipamento.id)}
```

## 4. Exclusão confirmada

Ajuste sua função de excluir no Dashboard para ser chamada apenas depois da confirmação:

```jsx
async function excluirEquipamento() {
    try {
        // Deleta o equipamento escolhido no banco.
        await axios.delete(`http://127.0.0.1:3003/equipamentos/${idParaExcluir}`)

        // Fecha a confirmação.
        setIdParaExcluir(null)

        // Exibe o aviso de sucesso.
        setMensagemSucesso('Equipamento excluído com sucesso!')

        // MANTENHA aqui a função que você JÁ usa para atualizar o catálogo e os cards.
    } catch (erro) {
        console.log(erro)
        // Não mostra sucesso quando houver erro.
    }
}
```

A URL é só um exemplo baseado no endereço usado anteriormente no TechStock. Mantenha sua URL atual, se for diferente.

## 5. Cadastro e edição

**Nas funções que você já possui**, adicione somente a linha após o `await` que salva no backend (e dentro do `try`):

```jsx
// Após o POST que cadastrou com sucesso:
setMensagemSucesso('Equipamento cadastrado com sucesso!')

// Após o PUT/PATCH que editou com sucesso:
setMensagemSucesso('Equipamento editado com sucesso!')
```

Não substitua sua função de cadastro/edição e mantenha a atualização atual da lista, a limpeza do formulário e todas as outras operações.

## 6. Mostrar os componentes

No final do `return` do Dashboard, mas ainda dentro do componente principal, adicione:

```jsx
{/* Confirmação antes de excluir. */}
{idParaExcluir !== null && (
    <ConfirmarExclusao
        aoCancelar={() => setIdParaExcluir(null)}
        aoConfirmar={excluirEquipamento}
    />
)}

{/* Sucesso após cadastro, edição ou exclusão. */}
{mensagemSucesso !== '' && (
    <AlertaSucesso
        mensagem={mensagemSucesso}
        aoFechar={() => setMensagemSucesso('')}
    />
)}
```

## 7. Sobre a paleta

Os componentes usam as variáveis CSS que já existem no TechStock, como:

`--gradient-warning`, `--gradient-success`, `--gradient-button`, `--text`, `--muted`, `--line`, `--coral`, `--green-soft` e `--surface`.

Não precisa criar ou editar as cores da paleta. Se você mudar a paleta depois, os alertas acompanham automaticamente.

## 8. Remover SweetAlert2

Depois de substituir os alertas antigos e remover `Swal.fire()` do frontend, execute:

```bash
npm uninstall sweetalert2
```

## Importante

Não tive acesso ao conteúdo **atual** do seu `pages/Dashboard/index.jsx`, por isso forneci **trechos de integração**, sem inventar ou substituir as outras funções que você já utiliza.

## 9. Sucesso automático (novo)

O Dashboard **não precisa mudar**. O componente `AlertaSucesso` espera 2 segundos, faz uma animação de saída por 400 ms e executa `aoFechar` automaticamente. O botão "Entendi" foi removido.
