// ALERTAS DO TECHSTOCK
// React + styled-components, sem SweetAlert2.

import { useEffect, useState } from 'react'

import {
    Fundo,
    Caixa,
    TopoAviso,
    TopoSucesso,
    IconeAviso,
    IconeSucesso,
    Etiqueta,
    Conteudo,
    Titulo,
    Mensagem,
    Botoes,
    BotaoCancelar,
    BotaoExcluir
} from './styled.jsx'


// ===========================================
// 1. CONFIRMAR A EXCLUSÃO
// Continua precisando dos botões.
// ===========================================
export function ConfirmarExclusao({ aoCancelar, aoConfirmar }) {
    return (
        <Fundo>
            <Caixa role="alertdialog" aria-modal="true" aria-labelledby="titulo-exclusao">
                <TopoAviso>
                    <IconeAviso>!</IconeAviso>
                    <Etiqueta>CONFIRMAÇÃO</Etiqueta>
                </TopoAviso>

                <Conteudo>
                    <Titulo id="titulo-exclusao">Excluir equipamento?</Titulo>
                    <Mensagem>
                        Essa ação não poderá ser desfeita. Deseja continuar?
                    </Mensagem>

                    <Botoes>
                        <BotaoCancelar type="button" onClick={aoCancelar}>
                            Cancelar
                        </BotaoCancelar>

                        <BotaoExcluir type="button" onClick={aoConfirmar}>
                            Sim, excluir
                        </BotaoExcluir>
                    </Botoes>
                </Conteudo>
            </Caixa>
        </Fundo>
    )
}


// ===========================================
// 2. ALERTA DE SUCESSO AUTOMÁTICO
// Aparece, espera 2 segundos e desaparece suavemente.
// ===========================================
export function AlertaSucesso({ mensagem, aoFechar }) {
    // Começa com a animação de entrada.
    const [saindo, setSaindo] = useState(false)

    useEffect(() => {
        // Após 2 segundos, inicia a animação de saída.
        const tempoSaida = setTimeout(() => {
            setSaindo(true)
        }, 2000)

        // Após a saída de 400 ms, remove o aviso da tela.
        const tempoFechar = setTimeout(() => {
            aoFechar()
        }, 2400)

        // Limpa os temporizadores quando o aviso é removido.
        return () => {
            clearTimeout(tempoSaida)
            clearTimeout(tempoFechar)
        }
    }, [aoFechar])

    return (
        <Fundo $saindo={saindo}>
            <Caixa $saindo={saindo} role="status" aria-live="polite">
                <TopoSucesso>
                    <IconeSucesso>✓</IconeSucesso>
                    <Etiqueta>OPERAÇÃO CONCLUÍDA</Etiqueta>
                </TopoSucesso>

                <Conteudo>
                    <Titulo>Tudo certo!</Titulo>

                    {/* Cadastro, edição e exclusão usam este mesmo aviso. */}
                    <Mensagem $semBotao>{mensagem}</Mensagem>
                </Conteudo>
            </Caixa>
        </Fundo>
    )
}
