// VISUAL DOS ALERTAS TECHSTOCK
// Usa as variáveis da paleta existente: palette-azul.css.

import styled, { keyframes } from 'styled-components'


// Entrada suave: o aviso aparece aos poucos.
const aparecer = keyframes`
    from { opacity: 0; }
    to { opacity: 1; }
`

// Saída suave: o aviso desaparece aos poucos.
const desaparecer = keyframes`
    from { opacity: 1; }
    to { opacity: 0; }
`

// O card entra levemente de baixo para cima.
const entrarCard = keyframes`
    from { opacity: 0; transform: translateY(20px) scale(0.97); }
    to { opacity: 1; transform: translateY(0) scale(1); }
`

// O card sai levemente para cima.
const sairCard = keyframes`
    from { opacity: 1; transform: translateY(0) scale(1); }
    to { opacity: 0; transform: translateY(-12px) scale(0.98); }
`


// Fundo escurecido, com animação de entrada e saída.
export const Fundo = styled.div`
    position: fixed;
    inset: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    background: rgba(27, 44, 75, 0.48);
    backdrop-filter: blur(4px);
    animation: ${props => props.$saindo ? desaparecer : aparecer} 0.4s ease forwards;
`

// Caixa central: animação leve de movimento e transparência.
export const Caixa = styled.div`
    width: 100%;
    max-width: 420px;
    overflow: hidden;
    border: 1px solid var(--line);
    border-radius: 22px;
    background: var(--surface);
    box-shadow: 0 22px 65px rgba(27, 44, 75, 0.25);
    text-align: center;
    animation: ${props => props.$saindo ? sairCard : entrarCard} 0.4s ease forwards;
`

export const TopoAviso = styled.div`
    padding: 24px 16px 18px;
    background: var(--gradient-warning);
    border-bottom: 1px solid var(--coral-soft);
`

export const TopoSucesso = styled.div`
    padding: 24px 16px 18px;
    background: var(--gradient-success);
    border-bottom: 1px solid var(--line);
`

export const IconeAviso = styled.div`
    width: 64px;
    height: 64px;
    margin: 0 auto 12px;
    border: 2px solid var(--coral);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--surface);
    color: var(--coral-dark);
    font-size: 36px;
    font-weight: 800;
`

export const IconeSucesso = styled.div`
    width: 64px;
    height: 64px;
    margin: 0 auto 12px;
    border: 2px solid var(--dash-border-disponiveis);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--surface);
    color: var(--dash-status-disponivel-text, #176b50);
    font-size: 32px;
    font-weight: 800;
`

export const Etiqueta = styled.div`
    color: var(--text);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 2px;
`

export const Conteudo = styled.div`
    padding: 25px 26px 28px;
`

export const Titulo = styled.h2`
    margin: 0 0 10px;
    color: var(--text);
    font-size: 24px;
    line-height: 1.25;
`

export const Mensagem = styled.p`
    margin: 0 0 ${props => props.$semBotao ? '0' : '24px'};
    color: var(--muted);
    font-size: 15px;
    line-height: 1.6;
`

export const Botoes = styled.div`
    display: flex;
    justify-content: center;
    gap: 10px;

    @media (max-width: 360px) {
        flex-direction: column;
    }
`

export const BotaoCancelar = styled.button`
    flex: 1;
    padding: 13px 18px;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: var(--green-soft);
    color: var(--green-dark);
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: transform 0.2s, filter 0.2s;

    &:hover { filter: brightness(0.97); transform: translateY(-1px); }
    &:focus-visible { outline: 3px solid var(--dash-focus, #65a4e2); outline-offset: 2px; }
`

export const BotaoExcluir = styled.button`
    flex: 1;
    padding: 13px 18px;
    border: 0;
    border-radius: 12px;
    background: linear-gradient(105deg, var(--coral-dark), var(--coral));
    color: #ffffff;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: transform 0.2s, filter 0.2s;

    &:hover { filter: brightness(1.07); transform: translateY(-1px); }
    &:focus-visible { outline: 3px solid var(--dash-focus, #65a4e2); outline-offset: 2px; }
`
