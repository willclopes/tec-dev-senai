# TechStock — Dashboard com alertas manuais integrados

## Atenção: arquivo atual do Dashboard não estava disponível

O `src/pages/Dashboard/index.jsx` incluído neste pacote é uma **implementação de referência completa** (formulário, cards e catálogo simples). Ela demonstra a integração funcionando, mas **não é uma atualização linha a linha da sua versão atual**. **Não substitua seu Dashboard original** se você quiser preservar exatamente o layout, filtros, paginação e demais funcionalidades.

Para implementar os alertas em seu Dashboard atual, sem alterar a página:

1. Copie os arquivos `src/components/Alertas/index.jsx` e `styled.jsx` para o frontend.
2. No `Dashboard/index.jsx` atual, importe `ConfirmarExclusao` e `AlertaSucesso`.
3. Adicione os estados `idParaExcluir` (começa com `null`) e `mensagemSucesso` (começa com `''`).
4. Ao clicar no botão Excluir, execute `setIdParaExcluir(equipamento.id)` em vez de apagar o registro.
5. Adicione a função `confirmarEExcluir()` do exemplo. Faça `axios.delete` **somente** depois da confirmação.
6. Após o `axios.post` bem-sucedido, use `setMensagemSucesso('Equipamento cadastrado com sucesso!')`.
7. Após o `axios.put` bem-sucedido, use `setMensagemSucesso('Equipamento editado com sucesso!')`.
8. Após o `axios.delete` bem-sucedido, use `setMensagemSucesso('Equipamento excluído com sucesso!')`.
9. No JSX da página, exiba os dois componentes exatamente como no final deste `Dashboard/index.jsx`.

## Importante sobre o fechamento automático

Corrigimos a repetição do temporizador ao sair: a versão anterior usava `useEffect(..., [aoFechar])` e recebia uma nova função a cada renderização do Dashboard. Agora o tempo começa **uma vez por montagem** do alerta (`[]`), o que evita que a animação de saída reinicie o contador. O fechamento ocorre após 2 segundos + 400 ms da animação.

## Teste

Com backend na porta 3003 e frontend aberto, teste cadastro, edição e exclusão. Se o seu backend tiver rotas ou formato de resposta diferente, preserve os endpoints originais do Dashboard.
