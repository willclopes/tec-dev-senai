// Visual de exemplo usando as cores já definidas em palette-azul.css.
// Você pode manter seu styled.jsx atual se preferir o layout original.

import styled from 'styled-components'

export const Pagina = styled.main`
    max-width: 1200px;
    margin: 0 auto;
    padding: 28px 20px 60px;
    color: var(--text);
`

export const Titulo = styled.h1`
    font-size: 30px;
    margin: 0 0 5px;
`

export const Descricao = styled.p`
    color: var(--muted);
    margin: 0 0 25px;
`

export const Resumo = styled.div`
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 14px;
    margin-bottom: 24px;

    @media (max-width: 760px) {
        grid-template-columns: repeat(2, 1fr);
    }
`

export const Card = styled.div`
    padding: 20px;
    background: var(--surface);
    border: 1px solid var(--line);
    border-top: 4px solid ${props => props.$cor};
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;

    strong { font-size: 28px; }
    span { color: var(--muted); font-size: 14px; }
`

export const Caixa = styled.section`
    padding: 25px;
    margin-bottom: 24px;
    border-radius: 18px;
    background: var(--surface);
    border: 1px solid var(--line);
    box-shadow: var(--shadow);

    h2 { margin: 0 0 20px; font-size: 20px; }
`

export const Formulario = styled.form`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;

    @media (max-width: 650px) { grid-template-columns: 1fr; }
`

export const Campo = styled.div`
    display: flex;
    flex-direction: column;
    gap: 7px;

    label { font-size: 14px; font-weight: 600; }
    input, select {
        padding: 12px;
        border: 1px solid var(--line);
        border-radius: 10px;
        background: var(--surface);
        color: var(--text);
        font: inherit;
        min-width: 0;
    }
`

export const Botoes = styled.div`
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
`

export const Botao = styled.button`
    padding: 11px 16px;
    border: 1px solid var(--line);
    border-radius: 10px;
    cursor: pointer;
    font-weight: 700;
    color: ${props => props.$secundario ? 'var(--green-dark)' : '#fff'};
    background: ${props => props.$secundario
        ? 'var(--green-soft)'
        : props.$perigo
            ? 'var(--coral-dark)'
            : 'var(--gradient-button)'};
`

export const CampoBusca = styled.input`
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    margin-bottom: 18px;
    border: 1px solid var(--line);
    border-radius: 10px;
    font: inherit;
`

export const TabelaContainer = styled.div`
    overflow-x: auto;
`

export const Tabela = styled.table`
    width: 100%;
    border-collapse: collapse;
    text-align: left;

    th, td { padding: 12px; border-bottom: 1px solid var(--line); }
    th { color: var(--muted); font-size: 13px; }
    td { font-size: 14px; }
`
