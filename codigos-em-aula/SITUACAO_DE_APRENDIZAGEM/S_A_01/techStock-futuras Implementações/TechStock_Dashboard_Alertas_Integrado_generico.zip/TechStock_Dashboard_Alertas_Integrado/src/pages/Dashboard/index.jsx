// EXEMPLO COMPLETO DO DASHBOARD COM ALERTAS MANUAIS.
// Para manter exatamente seu layout atual, compare este arquivo com o seu
// antes de substituir. Sua versão original não estava disponível para edição.

import { useEffect, useState } from 'react'
import axios from 'axios'

import { ConfirmarExclusao, AlertaSucesso } from '../../components/Alertas/index.jsx'

import {
    Pagina, Titulo, Descricao, Resumo, Card, Caixa,
    Formulario, Campo, Botoes, Botao, Tabela, TabelaContainer,
    CampoBusca
} from './styled.jsx'

// Endereço do backend TechStock.
const API = 'http://127.0.0.1:3003/equipamentos'

// Campos iniciais do formulário.
const formularioVazio = {
    nome: '',
    numero_serie: '',
    categoria: 'Notebook',
    status: 'Disponivel',
    data_aquisicao: ''
}

export function Dashboard() {

    // Livros? Não: aqui são os equipamentos do TechStock.
    const [equipamentos, setEquipamentos] = useState([])

    // Dados do formulário de cadastro/edição.
    const [formulario, setFormulario] = useState(formularioVazio)

    // null significa que estamos cadastrando um novo equipamento.
    const [idEditando, setIdEditando] = useState(null)

    // ID selecionado para EXCLUSÃO, antes de pedir confirmação.
    const [idParaExcluir, setIdParaExcluir] = useState(null)

    // A mesma mensagem é exibida após cadastro, edição ou exclusão.
    const [mensagemSucesso, setMensagemSucesso] = useState('')

    // Filtro simples da tabela.
    const [busca, setBusca] = useState('')

    // Busca os equipamentos no backend.
    async function carregarEquipamentos() {
        try {
            const resposta = await axios.get(`${API}?page=1&limit=1000`)

            // O backend pode devolver uma lista ou um objeto contendo a lista.
            const dados = resposta.data
            setEquipamentos(Array.isArray(dados) ? dados : (dados.equipamentos || dados.data || []))
        } catch (erro) {
            console.log('Erro ao buscar equipamentos:', erro)
        }
    }

    // Carrega ao entrar no Dashboard.
    useEffect(() => {
        carregarEquipamentos()
    }, [])

    // Atualiza o campo que a pessoa digitou.
    function alterarCampo(evento) {
        const { name, value } = evento.target
        setFormulario({ ...formulario, [name]: value })
    }

    // Envia o formulário: cadastra ou edita.
    async function salvarEquipamento(evento) {
        evento.preventDefault()

        try {
            if (idEditando === null) {
                // CADASTRO
                await axios.post(API, formulario)
                setMensagemSucesso('Equipamento cadastrado com sucesso!')
            } else {
                // EDIÇÃO
                await axios.put(`${API}/${idEditando}`, formulario)
                setMensagemSucesso('Equipamento editado com sucesso!')
            }

            // Limpa o formulário e atualiza a tabela.
            setFormulario(formularioVazio)
            setIdEditando(null)
            await carregarEquipamentos()

        } catch (erro) {
            console.log('Erro ao salvar equipamento:', erro)
        }
    }

    // Preenche o formulário com o equipamento escolhido.
    function editarEquipamento(equipamento) {
        setIdEditando(equipamento.id)
        setFormulario({
            nome: equipamento.nome,
            numero_serie: equipamento.numero_serie,
            categoria: equipamento.categoria,
            status: equipamento.status,
            data_aquisicao: equipamento.data_aquisicao
        })
        document.getElementById('cadastro')?.scrollIntoView({ behavior: 'smooth' })
    }

    // Desfaz a edição e volta ao cadastro normal.
    function cancelarEdicao() {
        setIdEditando(null)
        setFormulario(formularioVazio)
    }

    // Só é executada depois do clique em "Sim, excluir".
    async function confirmarEExcluir() {
        try {
            await axios.delete(`${API}/${idParaExcluir}`)

            // Fecha a confirmação e mostra o sucesso.
            setIdParaExcluir(null)
            setMensagemSucesso('Equipamento excluído com sucesso!')
            await carregarEquipamentos()

        } catch (erro) {
            console.log('Erro ao excluir equipamento:', erro)
        }
    }

    // Filtro do catálogo. Os demais recursos do seu catálogo original
    // devem ser mantidos caso você integre este código ao projeto existente.
    const filtrados = equipamentos.filter(equipamento =>
        equipamento.nome.toLowerCase().includes(busca.toLowerCase()) ||
        equipamento.numero_serie.toLowerCase().includes(busca.toLowerCase())
    )

    return (
        <Pagina>
            <Titulo>📦 TechStock — Dashboard</Titulo>
            <Descricao>Cadastre e acompanhe os equipamentos da empresa.</Descricao>

            {/* Cards de resumo, atualizados após cada operação. */}
            <Resumo>
                <Card $cor="var(--dash-border-total)">
                    <span>📦 Total</span><strong>{equipamentos.length}</strong>
                </Card>
                <Card $cor="var(--dash-border-disponiveis)">
                    <span>✅ Disponíveis</span>
                    <strong>{equipamentos.filter(e => e.status === 'Disponivel' || e.status === 'Disponível').length}</strong>
                </Card>
                <Card $cor="var(--dash-border-emprestados)">
                    <span>📤 Emprestados</span>
                    <strong>{equipamentos.filter(e => e.status === 'Emprestado').length}</strong>
                </Card>
                <Card $cor="var(--dash-border-manutencao)">
                    <span>🛠️ Em manutenção</span>
                    <strong>{equipamentos.filter(e => e.status === 'Manutenção').length}</strong>
                </Card>
            </Resumo>

            {/* Formulário de cadastro e edição. */}
            <Caixa id="cadastro">
                <h2>{idEditando === null ? '➕ Cadastrar equipamento' : '✏️ Editar equipamento'}</h2>

                <Formulario onSubmit={salvarEquipamento}>
                    <Campo>
                        <label>Nome</label>
                        <input name="nome" value={formulario.nome} onChange={alterarCampo} required />
                    </Campo>

                    <Campo>
                        <label>Número de série</label>
                        <input name="numero_serie" value={formulario.numero_serie} onChange={alterarCampo} required />
                    </Campo>

                    <Campo>
                        <label>Categoria</label>
                        <select name="categoria" value={formulario.categoria} onChange={alterarCampo}>
                            <option>Notebook</option>
                            <option>Monitor</option>
                            <option>Mouse</option>
                            <option>Teclado</option>
                            <option>Headset</option>
                            <option>Outro</option>
                        </select>
                    </Campo>

                    <Campo>
                        <label>Situação</label>
                        <select name="status" value={formulario.status} onChange={alterarCampo}>
                            <option value="Disponivel">Disponível</option>
                            <option value="Emprestado">Emprestado</option>
                            <option value="Manutenção">Em manutenção</option>
                        </select>
                    </Campo>

                    <Campo>
                        <label>Data de aquisição</label>
                        <input name="data_aquisicao" type="date" value={formulario.data_aquisicao} onChange={alterarCampo} required />
                    </Campo>

                    <Botoes>
                        <Botao type="submit">{idEditando === null ? 'Cadastrar' : 'Salvar edição'}</Botao>
                        {idEditando !== null && (
                            <Botao type="button" $secundario onClick={cancelarEdicao}>Cancelar edição</Botao>
                        )}
                    </Botoes>
                </Formulario>
            </Caixa>

            {/* Catálogo simples de exemplo. Preserve o seu catálogo atual
                na integração definitiva. */}
            <Caixa>
                <h2>📋 Catálogo de equipamentos</h2>
                <CampoBusca
                    placeholder="Buscar por nome ou número de série..."
                    value={busca}
                    onChange={evento => setBusca(evento.target.value)}
                />

                <TabelaContainer>
                    <Tabela>
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Série</th>
                                <th>Categoria</th>
                                <th>Situação</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filtrados.map(equipamento => (
                                <tr key={equipamento.id}>
                                    <td>{equipamento.nome}</td>
                                    <td>{equipamento.numero_serie}</td>
                                    <td>{equipamento.categoria}</td>
                                    <td>{equipamento.status}</td>
                                    <td>
                                        <Botoes>
                                            <Botao $secundario type="button" onClick={() => editarEquipamento(equipamento)}>
                                                Editar
                                            </Botao>

                                            {/* O clique NÃO exclui diretamente. */}
                                            <Botao $perigo type="button" onClick={() => setIdParaExcluir(equipamento.id)}>
                                                Excluir
                                            </Botao>
                                        </Botoes>
                                    </td>
                                </tr>
                            ))}
                            {filtrados.length === 0 && (
                                <tr><td colSpan="5">Nenhum equipamento encontrado.</td></tr>
                            )}
                        </tbody>
                    </Tabela>
                </TabelaContainer>
            </Caixa>

            {/* Alerta de confirmação: só aparece ao pedir exclusão. */}
            {idParaExcluir !== null && (
                <ConfirmarExclusao
                    aoCancelar={() => setIdParaExcluir(null)}
                    aoConfirmar={confirmarEExcluir}
                />
            )}

            {/* Um só alerta para cadastro, edição e exclusão.
                A saída é automática, após 2 segundos + animação. */}
            {mensagemSucesso !== '' && (
                <AlertaSucesso
                    mensagem={mensagemSucesso}
                    aoFechar={() => setMensagemSucesso('')}
                />
            )}
        </Pagina>
    )
}
