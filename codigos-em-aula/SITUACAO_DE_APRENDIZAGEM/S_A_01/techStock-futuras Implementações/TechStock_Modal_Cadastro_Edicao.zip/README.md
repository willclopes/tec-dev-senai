# TechStock — Formulário de Cadastro e Edição em Janela

A antiga caixa fixa de cadastro foi removida do Dashboard. O mesmo formulário agora abre como modal, com os campos **Nome, Número de série, Data de aquisição, Categoria e Situação**.

## O que mudou

- **Cadastrar Novo item** no Header: abre o modal vazio de qualquer página, sem mudar de rota.
- **Editar** no catálogo: abre o mesmo modal com os dados preenchidos.
- **Cancelar, X ou Esc**: fecha sem salvar.
- **Salvar**: chama o backend já existente em `http://127.0.0.1:3003/equipamentos`, fecha a janela e mostra o alerta de sucesso de 2 segundos.
- O Dashboard recarrega o catálogo e os cards depois de salvar.
- **Excluir**: continua usando a confirmação de exclusão e o sucesso animado de antes.
- Erros de cadastro/edição: o modal continua aberto, mostrando uma mensagem simples.

## Arquivos que você deve copiar

```text
src/
├── components/
│   ├── Header/
│   │   └── index.jsx          ← substitua (o styled.jsx permanece)
│   ├── Layout/
│   │   └── index.jsx          ← substitua
│   ├── ModalEquipamento/      ← nova pasta
│   │   ├── index.jsx
│   │   └── styled.jsx
│   └── Alertas/               ← cópia dos alertas atuais (opcional)
│       ├── index.jsx
│       └── styled.jsx
└── pages/
    └── Dashboard/
        └── index.jsx         ← substitua
```

**Não altere** `Dashboard/styled.jsx`, `Header/styled.jsx`, `Cards`, `Catalogo`, `Banner`, `Footer` ou `router.jsx`.

### Observação sobre o Header

O arquivo do exemplo mantém os links de navegação do Header que vínhamos usando. Se você modificou esses links, mantenha-os; a mudança necessária é:

```jsx
export function Header({ onCadastrar }) {
    function handleNovo(evento) {
        evento.preventDefault()
        onCadastrar()
    }

    // Dentro do JSX:
    // <BotaoNovo to="/dashboard" onClick={handleNovo}>+ Cadastrar Novo item</BotaoNovo>
}
```

O exemplo pressupõe que `BotaoNovo` ainda é `styled(Link)` em `Header/styled.jsx`, conforme as versões anteriores.

### Como a mesma janela abre em qualquer página?

O `Layout` já contém o `Header`, o `Footer` e o `<Outlet />`. Adicionamos o `ModalEquipamento` nele, então a janela não depende mais de estar no Dashboard.

Para usar o botão Editar em **outra página** que também liste equipamentos:

```jsx
import { useOutletContext } from 'react-router-dom'

const { abrirEdicao } = useOutletContext()

// No catálogo dessa página:
// <Catalogo ... mostrarAcoes={true} onEdit={abrirEdicao} />
```

**Atenção:** no seu `Catalogo`, `mostrarAcoes={true}` também pode exibir o botão Excluir; se ativar em outra página, implemente o tratamento do `onDelete` antes de exibi-lo.

## Prévia visual

Abra `preview.html` no navegador. É uma simulação local do visual (não envia dados à API).

## Testes

1. Entre no Dashboard e clique no **Cadastrar Novo item** do Header. O modal deve abrir vazio.
2. Preencha os campos e salve. Deve aparecer sucesso por 2 segundos, e os cards/catálogo devem atualizar.
3. Clique em **Editar** no catálogo. O modal deve abrir com os campos do equipamento preenchidos.
4. Salve a edição e confira a atualização.
5. Vá em Relatório ou Consultas; clique em **Cadastrar Novo item**. O modal deve abrir sem sair da página.
6. Clique em **Excluir** no catálogo do Dashboard; a confirmação e o sucesso devem funcionar como antes.

A versão atual do `Dashboard/index.jsx` foi baseada no arquivo que você enviou. Os exemplos de `Header/index.jsx` e `Layout/index.jsx` seguem a estrutura discutida na conversa porque esses dois arquivos atuais ainda não foram enviados.
