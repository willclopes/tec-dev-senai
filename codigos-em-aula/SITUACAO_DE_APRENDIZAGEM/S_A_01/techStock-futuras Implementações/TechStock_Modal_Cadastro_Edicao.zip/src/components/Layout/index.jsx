// LAYOUT DO TECHSTOCK
// Fica em todas as páginas normais do sistema.
// Por isso, a janela de cadastro funciona em qualquer tela.

import { useState } from 'react'
import { Outlet } from 'react-router-dom'

import { Header } from '../Header/index.jsx'
import { Footer } from '../Footer/index.jsx'
import { ModalEquipamento } from '../ModalEquipamento/index.jsx'
import { AlertaSucesso } from '../Alertas/index.jsx'

export function Layout() {
    // Quando true, a janela do formulário está aberta.
    const [modalAberto, setModalAberto] = useState(false)

    // null = cadastrar; objeto = editar.
    const [equipamentoEditar, setEquipamentoEditar] = useState(null)

    // Mensagem do alerta automático de 2 segundos.
    const [mensagemSucesso, setMensagemSucesso] = useState('')

    // Ao mudar este número, o Dashboard recarrega seu catálogo.
    const [atualizacao, setAtualizacao] = useState(0)

    // Abre um formulário vazio para cadastrar.
    function abrirCadastro() {
        setEquipamentoEditar(null)
        setModalAberto(true)
    }

    // Abre o mesmo formulário, com dados para editar.
    function abrirEdicao(equipamento) {
        setEquipamentoEditar(equipamento)
        setModalAberto(true)
    }

    // Fecha o formulário sem salvar.
    function fecharFormulario() {
        setModalAberto(false)
        setEquipamentoEditar(null)
    }

    // Chamado APÓS a API salvar com sucesso.
    function registroSalvo(acao) {
        fecharFormulario()

        if (acao === 'cadastro') {
            setMensagemSucesso('Equipamento cadastrado com sucesso!')
        } else {
            setMensagemSucesso('Equipamento editado com sucesso!')
        }

        // Avisa o Dashboard que precisa buscar os dados novamente.
        setAtualizacao(numero => numero + 1)
    }

    return (
        <>
            {/* Header aparece em todas as páginas do Layout. */}
            <Header onCadastrar={abrirCadastro} />

            <main>
                {/* Compartilha as funções com Dashboard e outras páginas. */}
                <Outlet context={{ abrirCadastro, abrirEdicao, atualizacao, mostrarSucesso: setMensagemSucesso }} />
            </main>

            <Footer />

            {/* Uma única janela serve para CADASTRO e EDIÇÃO. */}
            {modalAberto && (
                <ModalEquipamento
                    equipamento={equipamentoEditar}
                    aoFechar={fecharFormulario}
                    aoSalvar={registroSalvo}
                />
            )}

            {/* Mesma mensagem de sucesso para cadastro, edição e exclusão. */}
            {mensagemSucesso !== '' && (
                <AlertaSucesso
                    mensagem={mensagemSucesso}
                    aoFechar={() => setMensagemSucesso('')}
                />
            )}
        </>
    )
}
