// HEADER TECHSTOCK
// A única mudança funcional foi o botão "+ Cadastrar Novo item".
// Ele abre o modal em qualquer página, sem navegar para o Dashboard.

import { Logo } from '../Logo/index.jsx'
import {
    Barra,
    BotaoNovo,
    Faixa,
    LinkMenu,
    Navegacao,
    ContainerFlutuante
} from './styled.jsx'

export function Header({ onCadastrar }) {
    // BotaoNovo no seu Header é um styled(Link).
    // preventDefault impede que o Link mude de página.
    function handleNovo(evento) {
        evento.preventDefault()
        onCadastrar()
    }

    return (
        <ContainerFlutuante>
            <Faixa>
                <Barra>
                    <Logo />

                    <Navegacao>
                        <LinkMenu to="/primeiraversao">[Primeira Versão]</LinkMenu>
                        <LinkMenu to="/dashboard">📊 Dashboard</LinkMenu>
                        <LinkMenu to="/relatorio">📑 Relatório</LinkMenu>
                        <LinkMenu to="/consultas">🔍 Consultas</LinkMenu>
                    </Navegacao>

                    {/* Este botão agora abre o formulário como uma janela. */}
                    <BotaoNovo to="/dashboard" onClick={handleNovo}>
                        + Cadastrar Novo item
                    </BotaoNovo>
                </Barra>
            </Faixa>
        </ContainerFlutuante>
    )
}
