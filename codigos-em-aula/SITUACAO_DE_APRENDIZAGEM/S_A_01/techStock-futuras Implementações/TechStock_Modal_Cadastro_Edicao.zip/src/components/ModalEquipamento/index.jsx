// JANELA DE CADASTRO E EDIÇÃO DO TECHSTOCK
// Um componente para as duas situações.
// Se equipamento for null, cadastra. Se receber dados, edita.

import { useEffect, useState } from 'react'
import axios from 'axios'

import {
    FundoModal, Janela, Cabecalho, FaixaColorida, Titulo,
    Descricao, Fechar, Formulario, Campos, Campo,
    Grupo, Opcoes, Rodape, BotaoCancelar, BotaoSalvar, Erro
} from './styled.jsx'

export function ModalEquipamento({ equipamento, aoFechar, aoSalvar }) {
    // Começa vazio no cadastro e preenchido na edição.
    const [formData, setFormData] = useState({
        id: equipamento ? equipamento.id : '',
        nome: equipamento ? equipamento.nome : '',
        numero_serie: equipamento ? equipamento.numero_serie : '',
        data_aquisicao: equipamento ? (equipamento.data_aquisicao || '').slice(0, 10) : '',
        categoria: equipamento ? equipamento.categoria : '',
        status: equipamento ? equipamento.status : ''
    })

    const [salvando, setSalvando] = useState(false)
    const [fechando, setFechando] = useState(false)
    const [erro, setErro] = useState('')

    // Fecha com animação suave de 0,25 segundo.
    function fecharJanela() {
        if (salvando || fechando) return
        setFechando(true)
        setTimeout(aoFechar, 250)
    }

    // Fecha com ESC e não deixa rolar o conteúdo atrás da janela.
    useEffect(() => {
        document.body.style.overflow = 'hidden'

        function fecharComEsc(evento) {
            if (evento.key === 'Escape' && !salvando) {
                fecharJanela()
            }
        }

        document.addEventListener('keydown', fecharComEsc)

        return () => {
            document.body.style.overflow = ''
            document.removeEventListener('keydown', fecharComEsc)
        }
    }, [aoFechar, salvando, fechando])

    // Atualiza os campos conforme a pessoa digita.
    function handleInputChange(evento) {
        const { name, value } = evento.target
        setFormData(anterior => ({ ...anterior, [name]: value }))
    }

    // Salva no mesmo backend que o Dashboard já usa.
    async function handleSubmit(evento) {
        evento.preventDefault()
        setSalvando(true)
        setErro('')

        try {
            if (formData.id) {
                // Edita o equipamento existente.
                await axios.put(`http://127.0.0.1:3003/equipamentos/${formData.id}`, formData)
                setFechando(true)
                setTimeout(() => aoSalvar('edicao'), 250)
            } else {
                // Cadastra um novo equipamento.
                await axios.post('http://127.0.0.1:3003/equipamentos', formData)
                setFechando(true)
                setTimeout(() => aoSalvar('cadastro'), 250)
            }
        } catch (erro) {
            console.log('Erro ao salvar:', erro)
            setErro('Não foi possível salvar. Verifique os dados e tente novamente.')
        } finally {
            setSalvando(false)
        }
    }

    return (
        <FundoModal $fechando={fechando}>
            <Janela $fechando={fechando} role="dialog" aria-modal="true" aria-labelledby="titulo-modal">
                <FaixaColorida />

                <Cabecalho>
                    <div>
                        <Titulo id="titulo-modal">
                            {formData.id ? '✎ Editar equipamento' : '✦ Cadastrar equipamento'}
                        </Titulo>
                        <Descricao>
                            {formData.id
                                ? 'Altere os dados e salve suas mudanças.'
                                : 'Preencha os campos para adicionar um novo ativo.'}
                        </Descricao>
                    </div>

                    <Fechar type="button" onClick={fecharJanela} disabled={salvando || fechando} aria-label="Fechar janela">
                        ×
                    </Fechar>
                </Cabecalho>

                <Formulario onSubmit={handleSubmit}>
                    <Campos>
                        <Campo>
                            <label htmlFor="modal-nome">Nome do equipamento</label>
                            <input id="modal-nome" name="nome" type="text"
                                placeholder="Ex.: Notebook Dell"
                                value={formData.nome} onChange={handleInputChange} required autoFocus />
                        </Campo>

                        <Campo>
                            <label htmlFor="modal-serie">Número de série</label>
                            <input id="modal-serie" name="numero_serie" type="text"
                                placeholder="Ex.: NB-001"
                                value={formData.numero_serie} onChange={handleInputChange} required />
                        </Campo>

                        <Campo>
                            <label htmlFor="modal-data">Data de aquisição</label>
                            <input id="modal-data" name="data_aquisicao" type="date"
                                value={formData.data_aquisicao} onChange={handleInputChange} required />
                        </Campo>
                    </Campos>

                    <Grupo>
                        <legend>📦 Categoria</legend>
                        <Opcoes>
                            {['Monitor', 'Headset', 'Mouse', 'Teclado', 'Notebook', 'Acessório'].map(categoria => (
                                <label key={categoria}>
                                    <input type="radio" name="categoria" value={categoria}
                                        checked={formData.categoria === categoria}
                                        onChange={handleInputChange} required />
                                    {categoria === 'Acessório' ? 'Outro' : categoria}
                                </label>
                            ))}
                        </Opcoes>
                    </Grupo>

                    <Grupo>
                        <legend>🔖 Situação</legend>
                        <Opcoes>
                            {['Disponível', 'Emprestado', 'Manutenção'].map(status => (
                                <label key={status}>
                                    <input type="radio" name="status" value={status}
                                        checked={formData.status === status}
                                        onChange={handleInputChange} required />
                                    {status}
                                </label>
                            ))}
                        </Opcoes>
                    </Grupo>

                    {erro !== '' && <Erro>{erro}</Erro>}

                    <Rodape>
                        <BotaoCancelar type="button" onClick={fecharJanela} disabled={salvando || fechando}>
                            Cancelar
                        </BotaoCancelar>
                        <BotaoSalvar type="submit" disabled={salvando}>
                            {salvando ? 'Salvando...' : formData.id ? 'Salvar alterações' : '+ Cadastrar equipamento'}
                        </BotaoSalvar>
                    </Rodape>
                </Formulario>
            </Janela>
        </FundoModal>
    )
}
