// ESTILO DA JANELA DE CADASTRO E EDIÇÃO
// Usa somente as cores existentes em palette-azul.css.

import styled, { keyframes } from 'styled-components'

// Faz a janela aparecer suavemente.
const entrar = keyframes`
    from { opacity: 0; transform: translateY(24px) scale(0.97); }
    to { opacity: 1; transform: translateY(0) scale(1); }
`

const aparecer = keyframes`
    from { opacity: 0; }
    to { opacity: 1; }
`

const desaparecer = keyframes`
    from { opacity: 1; }
    to { opacity: 0; }
`

const sair = keyframes`
    from { opacity: 1; transform: translateY(0) scale(1); }
    to { opacity: 0; transform: translateY(-12px) scale(0.98); }
` 

export const FundoModal = styled.div`
    position: fixed;
    inset: 0;
    z-index: 9998;
    padding: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(27, 44, 75, 0.52);
    backdrop-filter: blur(5px);
    animation: ${props => props.$fechando ? desaparecer : aparecer} ${props => props.$fechando ? "0.25s" : "0.3s"} ease forwards;
`

export const Janela = styled.div`
    width: 100%;
    max-width: 760px;
    max-height: calc(100dvh - 36px);
    overflow-y: auto;
    border-radius: 22px;
    border: 1px solid var(--line);
    background: var(--surface);
    box-shadow: 0 25px 80px rgba(20, 38, 77, 0.28);
    animation: ${props => props.$fechando ? sair : entrar} ${props => props.$fechando ? "0.25s" : "0.35s"} ease forwards;
`

export const FaixaColorida = styled.div`
    height: 8px;
    background: var(--gradient-banner);
`

export const Cabecalho = styled.div`
    display: flex;
    align-items: start;
    justify-content: space-between;
    gap: 14px;
    padding: 24px 28px 14px;
    background: var(--gradient-page-light);

    @media (max-width: 600px) { padding: 20px 18px 12px; }
`

export const Titulo = styled.h2`
    margin: 0 0 6px;
    color: var(--text);
    font-size: 25px;
`

export const Descricao = styled.p`
    margin: 0;
    color: var(--muted);
    font-size: 14px;
`

export const Fechar = styled.button`
    width: 34px;
    height: 34px;
    flex-shrink: 0;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: var(--surface);
    color: var(--muted);
    cursor: pointer;
    font-size: 25px;
    line-height: 1;
    &:hover { color: var(--coral-dark); background: var(--coral-soft); }
`

export const Formulario = styled.form`
    padding: 18px 28px 26px;
    @media (max-width: 600px) { padding: 16px 18px 22px; }
`

export const Campos = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 20px;

    /* Em telas pequenas, os campos ficam um embaixo do outro. */
    @media (max-width: 600px) { grid-template-columns: 1fr; }
`

export const Campo = styled.div`
    display: flex;
    flex-direction: column;
    gap: 7px;

    label { color: var(--text); font-weight: 700; font-size: 13px; }

    input {
        width: 100%;
        box-sizing: border-box;
        padding: 12px 14px;
        border: 1px solid var(--line);
        border-radius: 12px;
        color: var(--text);
        background: var(--surface);
        font: inherit;
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;

        &:focus { border-color: var(--dash-focus); box-shadow: 0 0 0 3px var(--green-soft); }
    }
`

export const Grupo = styled.fieldset`
    min-width: 0;
    margin: 0 0 18px;
    padding: 16px;
    border: 1px solid var(--line);
    border-radius: 13px;
    background: var(--background);

    legend { padding: 0 7px; font-weight: 700; color: var(--text); font-size: 14px; }
`

export const Opcoes = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;

    label {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 10px 12px;
        background: var(--surface);
        font-size: 13px;
        color: var(--text);
        cursor: pointer;

        &:has(input:checked) { background: var(--green-soft); border-color: var(--green); color: var(--green-dark); }
    }

    input { accent-color: var(--green); cursor: pointer; }
`

export const Erro = styled.p`
    padding: 12px 14px;
    border-radius: 10px;
    background: var(--coral-soft);
    color: var(--coral-dark);
    font-size: 14px;
`

export const Rodape = styled.div`
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    border-top: 1px solid var(--line);
    padding-top: 18px;

    @media (max-width: 420px) { flex-direction: column-reverse; }
`

export const BotaoCancelar = styled.button`
    padding: 12px 20px;
    border-radius: 12px;
    border: 1px solid var(--line);
    background: var(--green-soft);
    color: var(--green-dark);
    font: inherit;
    font-weight: 700;
    cursor: pointer;
`

export const BotaoSalvar = styled.button`
    padding: 12px 22px;
    border-radius: 12px;
    border: none;
    background: var(--gradient-button);
    color: #fff;
    font: inherit;
    font-weight: 700;
    cursor: pointer;
    box-shadow: var(--shadow);
    &:disabled { opacity: 0.65; cursor: wait; }
    &:hover:not(:disabled) { filter: brightness(1.08); }
`
