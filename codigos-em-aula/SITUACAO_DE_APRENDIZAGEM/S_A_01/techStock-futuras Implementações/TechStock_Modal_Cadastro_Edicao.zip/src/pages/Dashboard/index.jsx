// DASHBOARD TECHSTOCK
// Mantivemos o Banner, os Cards, o Catálogo e a paginação originais.
// O cadastro e a edição agora abrem uma janela que existe no Layout.

import { useEffect, useState } from "react"
import { useOutletContext } from "react-router-dom"
import axios from "axios"

import { ContainerPrincipal, IndicadoresCards } from "./styled.jsx"
import { Cards } from "../../components/Cards/index.jsx"
import { Banner } from "../../components/Banner/index.jsx"
import { Catalogo } from "../../components/Catalogo/index.jsx"
import { ConfirmarExclusao } from "../../components/Alertas/index.jsx"

export function Dashboard() {
    // O Layout compartilha essas funções com todas as páginas.
    const { abrirEdicao, atualizacao, mostrarSucesso } = useOutletContext()

    const [equipamentos, setEquipamentos] = useState([])
    const [paginaAtual, setPaginaAtual] = useState(1)
    const [totalPaginas, setTotalPaginas] = useState(1)
    const [resumo, setResumo] = useState({})

    // ID do equipamento que o usuário quer excluir.
    const [idParaExcluir, setIdParaExcluir] = useState(null)

    // Busca os equipamentos no backend (mesma rota do código original).
    const fetchEquipamentos = async (pagina = paginaAtual) => {
        const response = await axios.get(`http://127.0.0.1:3003/equipamentos?page=${pagina}&limit=10`)
        setEquipamentos(response.data.data)
        setTotalPaginas(response.data.meta.totalPaginas)
        setResumo(response.data.resumo)
    }

    // Quando trocar de página OU salvar no modal, recarrega o catálogo.
    useEffect(() => {
        fetchEquipamentos(paginaAtual)
    }, [paginaAtual, atualizacao])

    // Editar: abre o MESMO formulário, com os dados já preenchidos.
    const handleEdit = (equipamento) => {
        abrirEdicao(equipamento)
    }

    // Excluir: primeiro abre a confirmação, sem apagar nada.
    const handleDelete = (id) => {
        setIdParaExcluir(id)
    }

    // Exclui apenas se a pessoa confirmar.
    const confirmarExclusao = async () => {
        try {
            await axios.delete(`http://127.0.0.1:3003/equipamentos/${idParaExcluir}`)
            setIdParaExcluir(null)
            mostrarSucesso('Equipamento excluído com sucesso!')
            await fetchEquipamentos()
        } catch (erro) {
            console.log('Erro ao excluir equipamento:', erro)
        }
    }

    return (
        <ContainerPrincipal>
            <Banner
                tituloSuperior="TECHSTOCK / INVENTÁRIO"
                title="Seu inventário em boas mãos."
                description="Organize, acompanhe e gerencie todos os equipamentos da empresa em um só lugar."
            />

            <IndicadoresCards>

        <Cards
          tipo="total"
          legenda="Total de ativos"
          numerocard={resumo.total}
          legendacard="Equipamentos cadastrados"
          icone="⌨"
        />
        <Cards
          tipo="disponiveis"
          legenda="Disponíveis"
          numerocard={resumo.disponiveis}
          legendacard="Prontos para utilização"
          icone="✔"
        />
        <Cards
          tipo="emprestados"
          legenda="Emprestados"
          numerocard={resumo.emprestados}
          legendacard="Em utilização"
          icone="⇄"
        />
        <Cards
          tipo="manutencao"
          legenda="Em manutenção"
          numerocard={resumo.manutencao}
          legendacard="Aguardando liberação"
          icone="🛠"
        />
            </IndicadoresCards>

            {/* O formulário fixo saiu daqui. O Header abre o modal em qualquer página. */}

      <Catalogo
        titulo="Catálogo de ativos"
        descricao="Equipamentos cadastrados na empresa."
        equipamentos={equipamentos}
        mostrarAcoes={true}
        onEdit={handleEdit}
        onDelete={handleDelete}
        paginaAtual={paginaAtual}
        totalPaginas={totalPaginas}
        onPaginaAnterior={() => setPaginaAtual(paginaAtual - 1)}
        onPaginaProxima={() => setPaginaAtual(paginaAtual + 1)}
      />

            {/* Alerta de exclusão existente no projeto, sem alteração visual. */}
            {idParaExcluir !== null && (
                <ConfirmarExclusao
                    aoCancelar={() => setIdParaExcluir(null)}
                    aoConfirmar={confirmarExclusao}
                />
            )}
        </ContainerPrincipal>
    )
}
